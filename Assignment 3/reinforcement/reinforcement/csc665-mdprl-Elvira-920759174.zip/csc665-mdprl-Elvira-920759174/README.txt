-Aitor Elvira Monsalve. 920759174
-I just could implement correctly the first 3 questions.
For question 3 I calculated the values Discount, Noise and Reward for each section, because the policy types were different.
-I spent the weekend doing this assignmnent.